----Readme----

Group Members:
Cameron Smith
Jared Lewis
Jacob Finton

1. input.txt is file being read from(assumed path in OSPROJ folder)

2. to make simulation time shorter/longer, edit the bubblesort method array length in IODevice and CPU

